# Association prediction of circRNA and disease based on multi-neural network fusion

## Dependecies
- Python 3.9
- dgl 0.9.1
- dgl-cuda 0.9.1
- numpy 1.22.3
- pytorch 1.13.0
- pytorch-cuda 11.6
- pandas 1.4.2

## Dataset
circRNA-disease associations:rna+dis+matrix.xlsx
circRNA features:rna_GaussianSimilarity.xlsx
disease features:dis+GIP+mesh+100.xlsx
circRNA centrality index features:rna+zhong+661.xlsx
disease centrality index features:dis+zhong+100.xlsx

###### How to run?
```
Run main.py

```
