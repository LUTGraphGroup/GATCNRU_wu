
import torch
import torch.nn as nn
import torch.nn.functional as F
from GATlayer import GATConv

from utils import train_features_choose, test_features_choose, build_heterograph
import pandas as pd
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

class MLP(nn.Module):
    def __init__(self, embedding_size, drop_rate):
        super(MLP, self).__init__()
        self.embedding_size = embedding_size  # 2807
        self.drop_rate = drop_rate

        def init_weights(m):
            if type(m) == nn.Linear:
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif type(m) == nn.Conv2d:
                nn.init.uniform_(m.weight)

        hidden_sizes = [self.embedding_size // 2, self.embedding_size // 4, self.embedding_size // 8,
                        self.embedding_size // 16]

        layers = []
        input_size = self.embedding_size

        for size in hidden_sizes:
            layers.append(nn.Linear(input_size, size))
            layers.append(nn.LeakyReLU())
            layers.append(nn.Dropout(self.drop_rate))
            input_size = size

        layers.append(nn.Linear(input_size, 1, bias=False))
        layers.append(nn.Sigmoid())

        self.mlp_prediction = nn.Sequential(*layers).to(device)
        self.mlp_prediction.apply(init_weights)

    def forward(self, rd_features_embedding):
        predict_result = self.mlp_prediction(rd_features_embedding)
        return predict_result



class CNNLayers(nn.Module):
    def __init__(self, heads):
        super(CNNLayers, self).__init__()
        self.heads = heads
        self.cnn_layers = nn.ModuleList()

        kernel_sizes = [1, 4, 16, 32]
        for kernel_size in kernel_sizes:
            self.cnn_layers.append(nn.Sequential(
                nn.Conv2d(in_channels=1, out_channels=6, kernel_size=(self.heads, kernel_size), padding=0),
                nn.ReLU(),
                nn.Flatten()
            ))

        # 定义卷积层的权重初始化函数
        def init_weights(m):
            if type(m) == nn.Linear:
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif type(m) == nn.Conv2d:
                nn.init.uniform_(m.weight)
        # 初始化
        for layer in self.cnn_layers:
            layer.apply(init_weights)

    def forward(self, x):
        cnn_output = []
        for layer in self.cnn_layers:
            cnn_output.append(layer(x))
        cnn_output = torch.cat(cnn_output, dim=1)
        return cnn_output



class GAT(nn.Module):
    def __init__(self, in_circfeat_size, in_disfeat_size, outfeature_size, heads, drop_rate, negative_slope,
                 features_embedding_size, negative_times):
        super(GAT, self).__init__()
        self.in_circfeat_size = in_circfeat_size
        self.in_disfeat_size = in_disfeat_size
        self.outfeature_size = outfeature_size
        self.heads = heads
        self.drop_rate = drop_rate
        self.negative_slope = negative_slope
        self.features_embedding_size = features_embedding_size
        self.negative_times = negative_times

        self.att_layer = GATConv(self.outfeature_size, self.outfeature_size, self.heads, self.drop_rate,
                                   self.drop_rate, self.negative_slope)

        self.W_rna = nn.Parameter(torch.zeros(size=(self.in_circfeat_size, self.outfeature_size)))
        self.W_dis = nn.Parameter(torch.zeros(size=(self.in_disfeat_size, self.outfeature_size)))
        nn.init.xavier_uniform_(self.W_rna.data, gain=1.414)
        nn.init.xavier_uniform_(self.W_dis.data, gain=1.414)

        self.gru_layer0 = nn.GRU(2778, 2778, 2).to(device)

        self.cnn_layers = CNNLayers(self.heads)

        self.mlp_prediction = MLP(self.features_embedding_size, self.drop_rate)

    def forward(self, graph, circ_feature_tensor, dis_feature_tensor, rel_matrix, train_model):
        circ_circ_f = circ_feature_tensor.mm(self.W_rna)
        dis_dis_f = dis_feature_tensor.mm(self.W_dis)
        N = circ_circ_f.size()[0] + dis_dis_f.size()[0]
        h_c_d_feature = torch.cat((circ_circ_f, dis_dis_f), dim=0)

        res = self.att_layer(graph, h_c_d_feature)
        x = res.view(N, 1, self.heads, -1)

        cnn_output = self.cnn_layers(x)

        cnn_outputs, _ = self.gru_layer0(cnn_output)

        rna_center = pd.read_excel(r'/usr/GATCNRU_wu/data/rna+zhong+661.xlsx', index_col=0)
        rna_center = rna_center.values
        dis_center = pd.read_excel(r'/usr/GATCNRU_wu/data/dis+zhong+100.xlsx', index_col=0)
        dis_center = dis_center.values
        circ_center_mat = torch.from_numpy(rna_center).to(torch.float32).to(device)
        disS_center_mat = torch.from_numpy(dis_center).to(torch.float32).to(device)
        center_mat = torch.cat([circ_center_mat, disS_center_mat], dim=0)
        cnn_outputs = torch.cat([cnn_outputs, center_mat], dim=1)

        if train_model:
            train_features_inputs, train_lable = train_features_choose(rel_matrix, cnn_outputs, self.negative_times)
            train_mlp_result = self.mlp_prediction(train_features_inputs)
            return train_mlp_result, train_lable
        else:
            test_features_inputs, test_lable = test_features_choose(rel_matrix, cnn_outputs)
            test_mlp_result = self.mlp_prediction(test_features_inputs)
            return test_mlp_result, test_lable







