import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

df = pd.read_csv('flod10/mean_cross_fpr_mean_att.csv',header=None)
fpr10 = df.values
df = pd.read_csv('flod10/mean_cross_tpr_mean_att.csv',header=None)
tpr10 = df.values
df = pd.read_csv('flod5/mean_cross_fpr_mean_att.csv',header=None)
fpr5 = df.values
df = pd.read_csv('flod5/mean_cross_tpr_mean_att.csv',header=None)
tpr5 = df.values
df = pd.read_csv('loocv/mean_cross_fpr_mean_att.csv',header=None)
fprl = df.values
df = pd.read_csv('loocv/mean_cross_tpr_mean_att.csv',header=None)
tprl = df.values


auc10 = np.trapz(tpr10[:,0], fpr10[:,0])
auc5 = np.trapz(tpr5[:,0], fpr5[:,0])
loocv = np.trapz(tprl[:,0], fprl[:,0])

plt.plot([0, 1], [0, 1], 'grey', linestyle='--')
plt.plot(fpr5, tpr5, 'dodgerblue', label='5CV AUC={:.4f}'.format(auc5))
plt.plot(fpr10, tpr10, 'darkorange', label='10CV AUC={:.4f}'.format(auc10))
plt.plot(fprl, tprl, 'peru', label='LOOCV AUC={:.4f}'.format(loocv))
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.legend(loc=0, fontsize=8)
# plt.savefig("Figure AUC of models.png")
plt.show()